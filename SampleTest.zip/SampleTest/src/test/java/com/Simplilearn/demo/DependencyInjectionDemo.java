package com.Simplilearn.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

public class DependencyInjectionDemo {
	
	public DependencyInjectionDemo(TestInfo test) {
		System.out.println(test.getDisplayName());
	}
	
	@Test
	@DisplayName("My Method")
	public void myTest(TestInfo info) {
		assertEquals("My Method", info.getDisplayName());
	}

	@Test
	@DisplayName("My Method")
	@Tag("mytag")
	public void Test1(TestInfo test) {
		assertEquals("My Method", test.getDisplayName());
		assertTrue(test.getTags().contains("mytag"));
	}
}
