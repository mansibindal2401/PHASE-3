package com.Simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class AssertionTest {

	public boolean checkAge(int age) {
		return age>=18;
	}
	
	@Test
	public void test() {
		assertEquals(6, 4+2);
		assertNotEquals(7, 2+3);
		assertTrue(checkAge(19));
	}
	
	@Test
	@DisplayName("Test Exception using Lambda")
	public void testThrow() {
		assertThrows(RuntimeException.class,()->{throw new RuntimeException("not valid");});
		
		assertThrows(ArithmeticException.class,()->{int x=10/0;System.out.println(x);});
	}
}
