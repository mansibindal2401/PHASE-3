package com.Simplilearn.demo;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

class SampletestCase {
	
	@BeforeAll
	public static void BeforeAll() {
		System.out.println("Before All");
	}
	
	
	@BeforeEach
	public void BeforeEach() {
		System.out.println("Before Each");
	}

	@Test
	public void Test1() {
		System.out.println("It is my first test case");
	}
	
	@AfterEach
	public void AfterEach() {
		System.out.println("After EAch");
	}
	
	@AfterAll
	public static void AfterAll() {
		System.out.println("After All");
	}

}
