package com.Simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class CalculatorTest {

private Calculator calc;

@BeforeEach
public void BeforeEach() {
	calc =new Calculator();
	System.out.println("Calculation Initiated");
}

@AfterEach
public void tearDown() {
	calc=null;
	System.out.println("Calculation stopped");
}

@Test
public void Addtest() {
	assertEquals(7,calc.add(4, 3));
}


@Test

public void Subract() {
	assertEquals(1,calc.subtract(4, 3));
}

@Test
public void Multiply() {
	assertEquals(12,calc.Multiply(4, 3));
	assertEquals(10,calc.Divide(100, 10));
}

}
