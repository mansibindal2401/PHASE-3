package com.Simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class NestedTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before all of outer");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("After all of outer");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("Before Each of outer");
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("After each of outer");
	}

	@Test
	@DisplayName("Outer Test")
	void testOuter() {
		System.out.println("Outer test");
	}
	@Nested
	class InnerClass{
		@BeforeEach
		void setUp() throws Exception {
			System.out.println("Before Each");
		}

		@AfterEach
		void tearDown() throws Exception {
			System.out.println("After each");
		}

		@Test
		@DisplayName("Outer Test")
		void testInner() {
			System.out.println("Inner test");
		}
		
		
		
		
	}

}
