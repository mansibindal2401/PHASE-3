package com.Simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

class ConditionalTests {

@Test
@EnabledOnOs({OS.WINDOWS})
public void runOnWindows() {
	System.out.println("Runs only on windows");
}

@Test
@EnabledOnOs({OS.MAC})
public void runOnMac() {
	System.out.println("Runs on MAC");
}


@Test
@DisabledOnOs({OS.MAC})
public void DisableOnMac() {
	System.out.println(" not Runs on MAC");
}


@Test
@EnabledOnOs({OS.LINUX})
public void EnableOnLinux() {
	System.out.println("Runs on MAC");
}

}
